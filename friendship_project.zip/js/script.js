// You can add your JavaScript code here for animations or password validation
document.querySelector('.button').addEventListener('click', function() {
    alert('Password submitted!');
});